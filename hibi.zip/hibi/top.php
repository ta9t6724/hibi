<!DOCTYPE html>
<html lang="jp">
<meta charset="utf-8">
<head>

	<title></title>
	<!-- ①CSS部分　-->
	<!-- <?php require('partial/css_link.php');?> -->
	<!-- XAMMPに起こる現象回避策　スーパーリロード　cmd＋shift＋R　-->

</head>
<body>
<!-- ②Navbar部分　-->
<!-- <?php require('partial/navbar.php');?> -->
<!-- ③Siderbar部分　-->

<!-- ④Footer部分　-->

<!-- ⑤JS部分　-->
<div class="container">

      <div class="row">

        <div class="col-lg-3">

          <img src="img/hibilogo.png">
         <ul class="list-group">
      <li class="list-group-item">TOP</li>
      <li class="list-group-item">今の日々</li>
      <li class="list-group-item">過去の日々</li>
      <li class="list-group-item">私の日々</li>
      <li class="list-group-item">みんなお題</li>
      <li class="list-group-item">サインイン</li>
      <li class="list-group-item">サイインアップ</li>
      </ul>

  </div>
<script type="text/javascript" src="assets/js/jquery-3.1.1.js"></script>
<script type="text/javascript" src="assets/js/jquery-migrate-1.4.1.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
</body>
</html>